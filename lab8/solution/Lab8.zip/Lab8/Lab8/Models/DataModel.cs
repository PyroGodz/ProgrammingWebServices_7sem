﻿

namespace Lab8.Models {
    public class DataModel {
        public string Key { get; set; }
        public string Value { get; set; }
    }
}