﻿using System.Collections.Generic;


namespace Lab8.Models {
    public class SessionList {
        public List<DataModel> sessions;
    }
}