﻿

namespace Lab8.Models {
    public class ResJsonRPCError {
        public string Id { get; set; }
        public ErrorJsonRPC Error { get; set; }
    }
}